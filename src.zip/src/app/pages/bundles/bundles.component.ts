import { Component } from '@angular/core';

@Component({
  selector: 'app-bundles',
  imports: [],
  templateUrl: './bundles.component.html',
  styleUrl: './bundles.component.css'
})
export class BundlesComponent {

}
